const express = require('express');
const {registerform,registeruser,loginform,loginuser,logout} = require('../controller/controller');
const {addcourse,addcourseform,updatecourse,updatecourseform,deletecourse} = require('../controller/coursecontroller');
const router = express.Router();

router.get("/register",registerform);
router.post("/register",registeruser);
router.get("/login",loginform);
router.post("/login",loginuser);
router.get("/logout",logout);

router.get("/addcourse",addcourseform);
router.post("/addcourse",addcourse);
router.get("/updatecourse/:id",updatecourseform);
router.patch("/updatecourse/:id",updatecourse);
router.get("/deletecourse/:id",deletecourse);

module.exports =router;