const mongoose = require('mongoose');

const course = mongoose.Schema({
    coursename:{
        type:String,
        required:true
    },
    trainername:{
        type:String,
        required:true
    },
    duration:{
        type:Number,
        min:100,
        required:true
    },
    fees:{
        type:Number,
        min:10000,
        required:true
    }
},{timestapms:true})

const coursemodel = mongoose.model("course",course);

module.exports = {coursemodel};
