const mongoose = require('mongoose');

const users = mongoose.Schema({
    name:{
        type:String,
        unique:true,
        required:true
    },
    email:{
        type:String,
        unique:true,
        required:true
    },
    password:{
        type:String,
        required:true
    }
},{timestamps:true});

const usermodel = mongoose.model("user",users);

module.exports = {usermodel} ;