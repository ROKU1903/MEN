const {response} = require('express');
const {coursemodel} = require('../model/course');

const addcourseform = async(req,resp)=>{
    resp.render("addcourse");
}

const addcourse =async(req,resp)=>{
    try {
        const data = new coursemodel({
            coursename:req.body.coursename,
            trainername:req.body.trainername,
            duration:req.body.duration,
            fees:req.body.fees
        });
        await data.save();
        resp.redirect("/dashboard");
    } catch (error) {
        console.log(error);
    }
}

const updatecourseform = async(req,resp)=>{
    resp.render("updatecourse");
}

const updatecourse = async(req,resp)=>{
    try {
        const data = await coursemodel.findByIdAndUpdate(req.params.id,req.body,{new:true});
        resp.redirect("/dashboard");
    } catch (error) {
        console.log(error);
    }
}

const deletecourse = async(req,resp)=>{
    await coursemodel.destroy();
    resp.redirect("/dashboard");
}

module.exports ={addcourse,addcourseform,updatecourse,updatecourseform,deletecourse}