const {response} = require('express');
const {usermodel} = require('../model/model');

const registerform  = async(req,resp)=>{
    resp.render("register");
}
const registeruser =async(req,resp)=>{
    try {
        const data = new usermodel({
            name:req.body.name,
            email:req.body.email,
            password:req.body.password
        });
        await data.save();
        resp.redirect("/login");
    } catch (error) {
        console.log(error);
    }
}

const loginform = async(req,resp)=>{
    resp.render("login");
}

const loginuser = async(req,resp)=>{
    try {
        const data = await usermodel.find(req.body);
        if (password=data.password){
            resp.redirect("/dashboard");
        } else {
            resp.redirect("/login");
        }
    } catch (error) {
        console.log(error);
    }
}

const logout = async(req,resp)=>{
    await usermodel.destroy();
    resp.redirect("/login");
}

module.exports ={registerform,registeruser,loginform,loginuser,logout};